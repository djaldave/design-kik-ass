public interface SearchStrategy {
    int search(int[] arr, int searchItem);
}
